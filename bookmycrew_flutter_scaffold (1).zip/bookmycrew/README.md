# BookMyCrew — Flutter Scaffold

## What's built

- **Design system**: `lib/core/theme/` — black/gold/warm-white dark
  theme (Fraunces display + Inter body), consistent rounded cards,
  inputs, buttons, chips.
- **Signature motion element**: `GoldThreadIndicator` — a gold line
  that draws itself under active tabs/inputs/selections. Used
  intentionally in only a few places so it stays meaningful.
- **Working phone-OTP auth flow**: `lib/features/auth/` —
  `PhoneInputScreen` → Firebase sends OTP → `OtpVerificationScreen` →
  signs the user in → routes to the worker search screen (now the
  post-auth home). State is managed with Riverpod so screens stay
  thin.
- **Customer Worker Search module**: `lib/features/worker_search/` +
  `lib/features/worker_profile/`
  - Firestore-backed search: only `verificationStatus: verified`
    workers are ever queryable by customers.
  - Filters: category, city, price range, minimum rating, availability
    date, max distance, and 4 sort modes (nearest, price, rating,
    experience).
  - Cursor-based pagination (`startAfterDocument`, 12/page),
    infinite-scroll trigger, pull-to-refresh.
  - Shimmer skeleton cards on first load, matching the real card's
    exact layout so there's no jump when content arrives.
  - Premium `WorkerCard`: photo, name, verified badge, CrewScore pill,
    star rating + review count, completed jobs, distance, languages,
    experience, hourly rate.
  - `WorkerProfileScreen`: hero photo, stats row, portfolio grid
    (tap-to-fullscreen viewer), single-month availability calendar
    (tap a date to select it), reviews list with the 6-axis rating
    breakdown, and a sticky bottom "Book Now" bar that activates once
    a date is picked.
  - `firestore.indexes.json`: every composite index these queries need
    — deploy with `firebase deploy --only firestore:indexes`.

## What's stubbed / next

- `lib/firebase_options.dart` has placeholder keys. Run:
  ```
  dart pub global activate flutterfire_cli
  flutterfire configure
  ```
  against your real Firebase project to replace it.
- No role picker yet — after first OTP verification, a brand-new user
  needs a screen to choose Customer / Worker / Event Manager, which
  then creates their `users/{uid}` doc (see the architecture doc for
  the schema). The `// TODO` in `otp_verification_screen.dart` marks
  exactly where to hook that in.
- "Book Now" currently just shows a snackbar — the actual booking flow
  (creates a `bookings` doc, kicks off the Razorpay order) is the next
  module to build; the `// TODO` in `worker_profile_screen.dart` marks
  where it plugs in.
- Worker search currently filters by exact `city` match. Multi-city
  autocomplete / "near me across city boundaries" is a Phase 2 nicety,
  not needed for single-city MVP launch.
- Distance search relies on `geolocator` + a client-side haversine
  calculation, not a native Firestore geo query (Firestore has none
  built in). At MVP city-scale this is the right tradeoff — see the
  doc comment in `worker_search_service.dart` for when to swap to a
  dedicated geo/search index.

## Running it

```
flutter pub get
flutterfire configure   # replaces firebase_options.dart with real keys
firebase deploy --only firestore:indexes
flutter run
```

You'll also need, in the Firebase console:
- Phone sign-in enabled under Authentication providers
- A test phone number added under Authentication → Sign-in method →
  Phone numbers for testing (so you can develop without burning real
  SMS/OTP quota)
- Firestore created in production mode with security rules per the
  architecture doc (worker/booking read-write scoping)
- A few `workers` documents with `verificationStatus: "verified"` and
  a matching `city` to actually see results in search — an empty
  collection will correctly show the "no workers match" empty state,
  not an error.

## Suggested next build step

The booking flow: tapping "Book Now" on a worker with a date selected
should create a `bookings` doc and kick off a Razorpay order, per the
payment flow in the architecture doc.

