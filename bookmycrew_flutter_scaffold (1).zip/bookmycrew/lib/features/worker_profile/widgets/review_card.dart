import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../core/models/review_model.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/app_card.dart';

class ReviewCard extends StatelessWidget {
  const ReviewCard({super.key, required this.review});

  final Review review;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(review.customerName, style: theme.textTheme.titleMedium),
              Row(
                children: [
                  const Icon(Icons.star_rounded,
                      size: 16, color: AppColors.gold),
                  const SizedBox(width: 2),
                  Text(review.overall.toStringAsFixed(1),
                      style: theme.textTheme.labelLarge),
                ],
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            DateFormat('MMM d, yyyy').format(review.createdAt),
            style: theme.textTheme.bodyMedium,
          ),
          if (review.comment != null && review.comment!.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(review.comment!, style: theme.textTheme.bodyLarge),
          ],
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _SubScore(label: 'Punctuality', score: review.punctuality),
              _SubScore(label: 'Professionalism', score: review.professionalism),
              _SubScore(label: 'Behaviour', score: review.behaviour),
              _SubScore(label: 'Grooming', score: review.grooming),
              _SubScore(label: 'Communication', score: review.communication),
              _SubScore(label: 'Teamwork', score: review.teamwork),
            ],
          ),
        ],
      ),
    );
  }
}

class _SubScore extends StatelessWidget {
  const _SubScore({required this.label, required this.score});

  final String label;
  final int score;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.surfaceElevated,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label,
              style: const TextStyle(
                  color: AppColors.textSecondary, fontSize: 11)),
          const SizedBox(width: 6),
          Text('$score',
              style: const TextStyle(
                  color: AppColors.gold,
                  fontSize: 11,
                  fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
