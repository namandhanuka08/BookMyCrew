import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/gold_thread_indicator.dart';

/// Simple single-month grid. Available dates render as filled gold
/// circles; everything else (past dates, unavailable dates) is
/// disabled/muted. This is intentionally a browsing/selection tool for
/// the profile page, not a full scheduling widget — booking flow
/// re-confirms the date server-side before payment anyway.
class AvailabilityCalendar extends StatefulWidget {
  const AvailabilityCalendar({
    super.key,
    required this.availableDates, // "yyyy-MM-dd" strings
    required this.onDateSelected,
  });

  final List<String> availableDates;
  final ValueChanged<DateTime> onDateSelected;

  @override
  State<AvailabilityCalendar> createState() => _AvailabilityCalendarState();
}

class _AvailabilityCalendarState extends State<AvailabilityCalendar> {
  late DateTime _visibleMonth;
  DateTime? _selected;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _visibleMonth = DateTime(now.year, now.month);
  }

  bool _isAvailable(DateTime day) {
    final key = DateFormat('yyyy-MM-dd').format(day);
    return widget.availableDates.contains(key);
  }

  void _changeMonth(int delta) {
    setState(() {
      _visibleMonth = DateTime(_visibleMonth.year, _visibleMonth.month + delta);
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final firstOfMonth = DateTime(_visibleMonth.year, _visibleMonth.month, 1);
    final daysInMonth =
        DateTime(_visibleMonth.year, _visibleMonth.month + 1, 0).day;
    // Monday-first grid offset (weekday: Mon=1..Sun=7)
    final leadingBlanks = firstOfMonth.weekday - 1;
    final today = DateTime.now();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              DateFormat('MMMM yyyy').format(_visibleMonth),
              style: theme.textTheme.titleMedium,
            ),
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.chevron_left, size: 20),
                  onPressed: () => _changeMonth(-1),
                ),
                IconButton(
                  icon: const Icon(Icons.chevron_right, size: 20),
                  onPressed: () => _changeMonth(1),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: ['M', 'T', 'W', 'T', 'F', 'S', 'S']
              .map((d) => Expanded(
                    child: Center(
                      child: Text(d, style: theme.textTheme.bodyMedium),
                    ),
                  ))
              .toList(),
        ),
        const SizedBox(height: 4),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 7,
            mainAxisSpacing: 4,
            crossAxisSpacing: 4,
          ),
          itemCount: leadingBlanks + daysInMonth,
          itemBuilder: (context, index) {
            if (index < leadingBlanks) return const SizedBox.shrink();
            final day = index - leadingBlanks + 1;
            final date =
                DateTime(_visibleMonth.year, _visibleMonth.month, day);
            final isPast = date.isBefore(DateTime(today.year, today.month, today.day));
            final available = !isPast && _isAvailable(date);
            final isSelected = _selected != null &&
                _selected!.year == date.year &&
                _selected!.month == date.month &&
                _selected!.day == date.day;

            return GestureDetector(
              onTap: available
                  ? () {
                      setState(() => _selected = date);
                      widget.onDateSelected(date);
                    }
                  : null,
              child: Container(
                decoration: BoxDecoration(
                  color: isSelected
                      ? AppColors.gold
                      : available
                          ? AppColors.gold.withOpacity(0.15)
                          : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                ),
                alignment: Alignment.center,
                child: Text(
                  '$day',
                  style: TextStyle(
                    color: isSelected
                        ? AppColors.background
                        : available
                            ? AppColors.gold
                            : AppColors.textDisabled,
                    fontWeight:
                        available ? FontWeight.w600 : FontWeight.w400,
                    fontSize: 13,
                  ),
                ),
              ),
            );
          },
        ),
        if (_selected != null) ...[
          const SizedBox(height: 12),
          Row(
            children: [
              Text(
                'Selected: ${DateFormat('EEE, MMM d').format(_selected!)}',
                style: theme.textTheme.bodyLarge,
              ),
              const SizedBox(width: 8),
              const GoldThreadIndicator(width: 24, active: true),
            ],
          ),
        ],
      ],
    );
  }
}
