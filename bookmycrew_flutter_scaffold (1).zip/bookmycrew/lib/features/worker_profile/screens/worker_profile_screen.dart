import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/models/worker_model.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../worker_search/widgets/crew_score_pill.dart';
import '../../worker_search/widgets/verified_badge.dart';
import '../providers/worker_profile_provider.dart';
import '../widgets/availability_calendar.dart';
import '../widgets/portfolio_grid.dart';
import '../widgets/review_card.dart';

class WorkerProfileScreen extends ConsumerStatefulWidget {
  const WorkerProfileScreen({super.key, required this.workerId});

  final String workerId;

  @override
  ConsumerState<WorkerProfileScreen> createState() =>
      _WorkerProfileScreenState();
}

class _WorkerProfileScreenState extends ConsumerState<WorkerProfileScreen> {
  DateTime? _selectedDate;

  @override
  Widget build(BuildContext context) {
    final workerAsync = ref.watch(workerDetailProvider(widget.workerId));

    return Scaffold(
      body: workerAsync.when(
        loading: () => const _ProfileSkeleton(),
        error: (e, _) => Center(child: Text('Could not load profile: $e')),
        data: (worker) {
          if (worker == null) {
            return const Center(child: Text('This profile is no longer available'));
          }
          return _ProfileContent(
            worker: worker,
            selectedDate: _selectedDate,
            onDateSelected: (d) => setState(() => _selectedDate = d),
          );
        },
      ),
    );
  }
}

class _ProfileContent extends ConsumerWidget {
  const _ProfileContent({
    required this.worker,
    required this.selectedDate,
    required this.onDateSelected,
  });

  final Worker worker;
  final DateTime? selectedDate;
  final ValueChanged<DateTime> onDateSelected;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final reviewsAsync = ref.watch(workerReviewsProvider(worker.uid));

    return Stack(
      children: [
        CustomScrollView(
          slivers: [
            SliverAppBar(
              expandedHeight: 240,
              pinned: true,
              backgroundColor: AppColors.background,
              flexibleSpace: FlexibleSpaceBar(
                background: worker.profilePhotoUrl == null
                    ? Container(color: AppColors.surfaceElevated)
                    : CachedNetworkImage(
                        imageUrl: worker.profilePhotoUrl!,
                        fit: BoxFit.cover,
                      ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 120),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(worker.name,
                              style: theme.textTheme.displayMedium),
                        ),
                        if (worker.isVerified) const VerifiedBadge(size: 24),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      worker.categories.join(' · '),
                      style: theme.textTheme.bodyLarge,
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        const Icon(Icons.star_rounded,
                            size: 18, color: AppColors.gold),
                        const SizedBox(width: 4),
                        Text('${worker.ratingAvg.toStringAsFixed(1)}',
                            style: theme.textTheme.titleMedium),
                        Text(' (${worker.ratingCount} reviews)',
                            style: theme.textTheme.bodyMedium),
                        const SizedBox(width: 14),
                        CrewScorePill(score: worker.crewScore),
                      ],
                    ),
                    const SizedBox(height: 20),
                    _StatsRow(worker: worker),
                    const SizedBox(height: 24),
                    if (worker.languages.isNotEmpty) ...[
                      Text('Languages', style: theme.textTheme.titleMedium),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        children: worker.languages
                            .map((l) => Chip(label: Text(l)))
                            .toList(),
                      ),
                      const SizedBox(height: 24),
                    ],
                    Text('Portfolio', style: theme.textTheme.titleMedium),
                    const SizedBox(height: 12),
                    PortfolioGrid(imageUrls: worker.portfolioUrls),
                    const SizedBox(height: 28),
                    Text('Availability', style: theme.textTheme.titleMedium),
                    const SizedBox(height: 12),
                    AvailabilityCalendar(
                      availableDates: worker.availableDates,
                      onDateSelected: onDateSelected,
                    ),
                    const SizedBox(height: 28),
                    Text('Reviews', style: theme.textTheme.titleMedium),
                    const SizedBox(height: 12),
                    reviewsAsync.when(
                      loading: () => const Padding(
                        padding: EdgeInsets.symmetric(vertical: 20),
                        child: Center(
                            child: CircularProgressIndicator(
                                color: AppColors.gold, strokeWidth: 2)),
                      ),
                      error: (e, _) =>
                          Text('Reviews unavailable', style: theme.textTheme.bodyMedium),
                      data: (reviews) {
                        if (reviews.isEmpty) {
                          return Text('No reviews yet',
                              style: theme.textTheme.bodyMedium);
                        }
                        return Column(
                          children: reviews
                              .map((r) => Padding(
                                    padding: const EdgeInsets.only(bottom: 12),
                                    child: ReviewCard(review: r),
                                  ))
                              .toList(),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: _BookNowBar(worker: worker, selectedDate: selectedDate),
        ),
      ],
    );
  }
}

class _StatsRow extends StatelessWidget {
  const _StatsRow({required this.worker});

  final Worker worker;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    Widget stat(String label, String value) => Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: AppTypography.priceText.copyWith(
                  color: AppColors.textPrimary, fontSize: 15)),
              const SizedBox(height: 2),
              Text(label, style: theme.textTheme.bodyMedium),
            ],
          ),
        );

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.divider),
      ),
      child: Row(
        children: [
          stat('${worker.completedJobs}', 'Jobs done'),
          stat('${worker.experienceYears} yrs', 'Experience'),
          stat('₹${worker.hourRate.toStringAsFixed(0)}/hr', 'Rate'),
        ],
      ),
    );
  }
}

class _BookNowBar extends StatelessWidget {
  const _BookNowBar({required this.worker, required this.selectedDate});

  final Worker worker;
  final DateTime? selectedDate;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: EdgeInsets.fromLTRB(
          20, 14, 20, MediaQuery.of(context).padding.bottom + 14),
      decoration: BoxDecoration(
        color: AppColors.background,
        border: const Border(top: BorderSide(color: AppColors.divider)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('₹${worker.hourRate.toStringAsFixed(0)}/hr',
                    style: AppTypography.priceText),
                Text(
                  selectedDate == null
                      ? 'Select a date above'
                      : 'For ${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}',
                  style: theme.textTheme.bodyMedium,
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: ElevatedButton(
              // TODO: wire to booking-flow creation (bookings doc +
              // Razorpay order) once that module is built.
              onPressed: selectedDate == null
                  ? null
                  : () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text('Booking flow coming next')),
                      );
                    },
              child: const Text('Book Now'),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileSkeleton extends StatelessWidget {
  const _ProfileSkeleton();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: CircularProgressIndicator(color: AppColors.gold),
    );
  }
}
