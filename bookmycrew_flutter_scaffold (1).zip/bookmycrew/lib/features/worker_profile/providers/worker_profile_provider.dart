import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/models/review_model.dart';
import '../../../core/models/worker_model.dart';

final _firestoreProvider = Provider<FirebaseFirestore>(
  (ref) => FirebaseFirestore.instance,
);

/// Live worker doc — auto-updates the profile screen if e.g. the
/// worker's rating changes while the customer has the screen open.
final workerDetailProvider =
    StreamProvider.family<Worker?, String>((ref, workerId) {
  final db = ref.watch(_firestoreProvider);
  return db
      .collection('workers')
      .doc(workerId)
      .snapshots()
      .map((doc) => doc.exists ? Worker.fromFirestore(doc) : null);
});

/// Most recent reviews for this worker, newest first. Capped at 20 —
/// the profile screen shows a "see all reviews" affordance beyond
/// that rather than paginating infinitely on a detail page.
final workerReviewsProvider =
    FutureProvider.family<List<Review>, String>((ref, workerId) async {
  final db = ref.watch(_firestoreProvider);
  final snapshot = await db
      .collection('ratings')
      .where('workerId', isEqualTo: workerId)
      .orderBy('createdAt', descending: true)
      .limit(20)
      .get();
  return snapshot.docs.map(Review.fromFirestore).toList();
});
