import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/widgets/gold_thread_indicator.dart';
import '../auth/providers/auth_provider.dart';

/// Placeholder landing screen post-auth. Real implementation is the
/// worker-search/browse screen described in the architecture doc —
/// this just proves the auth -> home hand-off works end to end.
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final authState = ref.watch(authStateProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('BookMyCrew')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("You're signed in", style: theme.textTheme.headlineLarge),
            const SizedBox(height: 8),
            authState.when(
              data: (user) => Text(
                user?.phoneNumber ?? 'No phone on record',
                style: theme.textTheme.bodyMedium,
              ),
              loading: () => const CircularProgressIndicator(),
              error: (e, _) => Text('$e', style: theme.textTheme.bodyMedium),
            ),
            const SizedBox(height: 16),
            const GoldThreadIndicator(active: true, width: 64),
          ],
        ),
      ),
    );
  }
}
