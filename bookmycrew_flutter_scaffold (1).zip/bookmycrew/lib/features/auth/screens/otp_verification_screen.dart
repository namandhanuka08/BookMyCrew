import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/gold_thread_indicator.dart';
import '../providers/auth_provider.dart';

class OtpVerificationScreen extends ConsumerStatefulWidget {
  const OtpVerificationScreen({super.key});

  @override
  ConsumerState<OtpVerificationScreen> createState() =>
      _OtpVerificationScreenState();
}

class _OtpVerificationScreenState
    extends ConsumerState<OtpVerificationScreen> {
  String _code = '';
  bool _focused = false;

  Future<void> _verify() async {
    if (_code.length != 6) return;
    final credential =
        await ref.read(otpFlowProvider.notifier).verifyOtp(_code);

    final state = ref.read(otpFlowProvider);
    if (!mounted) return;

    if (state.error != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(state.error!)));
      return;
    }

    if (credential != null) {
      // TODO: route based on whether this uid already has a
      // users/{uid} doc with a role set. New users -> role picker
      // (Customer / Worker / Event Manager). Existing users -> home.
      Navigator.of(context).popUntil((route) => route.isFirst);
    }
  }

  @override
  Widget build(BuildContext context) {
    final otpState = ref.watch(otpFlowProvider);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 16),
              Text('Enter the code', style: theme.textTheme.headlineLarge),
              const SizedBox(height: 8),
              Text(
                'Sent to ${otpState.phoneNumber ?? 'your phone'}',
                style: theme.textTheme.bodyMedium,
              ),
              const SizedBox(height: 32),
              PinCodeTextField(
                appContext: context,
                length: 6,
                keyboardType: TextInputType.number,
                animationType: AnimationType.fade,
                onChanged: (value) => setState(() => _code = value),
                onTap: () => setState(() => _focused = true),
                textStyle: theme.textTheme.titleMedium,
                pinTheme: PinTheme(
                  shape: PinCodeFieldShape.box,
                  borderRadius: BorderRadius.circular(12),
                  fieldHeight: 52,
                  fieldWidth: 44,
                  activeColor: AppColors.gold,
                  selectedColor: AppColors.gold,
                  inactiveColor: AppColors.divider,
                  activeFillColor: AppColors.surface,
                  selectedFillColor: AppColors.surface,
                  inactiveFillColor: AppColors.surface,
                ),
              ),
              const SizedBox(height: 4),
              // Signature gold-thread — draws in only while the pin
              // field has focus, echoing the active input.
              GoldThreadIndicator(active: _focused, width: 44),
              const SizedBox(height: 24),
              TextButton(
                onPressed: otpState.isLoading
                    ? null
                    : () {
                        final phone = otpState.phoneNumber;
                        if (phone != null) {
                          ref.read(otpFlowProvider.notifier).sendOtp(phone);
                        }
                      },
                child: const Text('Resend code'),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: (otpState.isLoading || _code.length != 6)
                      ? null
                      : _verify,
                  child: otpState.isLoading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: AppColors.background,
                          ),
                        )
                      : const Text('Verify & continue'),
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}
