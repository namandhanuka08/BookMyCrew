import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/services/auth_service.dart';

final authServiceProvider = Provider<AuthService>((ref) => AuthService());

final authStateProvider = StreamProvider<User?>((ref) {
  return ref.watch(authServiceProvider).authStateChanges;
});

/// Drives the phone -> OTP screen flow. Holds the verificationId once
/// Firebase sends the code, and surfaces loading/error state to the UI
/// so screens stay dumb (just read state, call notifier methods).
class OtpFlowState {
  const OtpFlowState({
    this.verificationId,
    this.isLoading = false,
    this.error,
    this.phoneNumber,
  });

  final String? verificationId;
  final bool isLoading;
  final String? error;
  final String? phoneNumber;

  OtpFlowState copyWith({
    String? verificationId,
    bool? isLoading,
    String? error,
    String? phoneNumber,
  }) {
    return OtpFlowState(
      verificationId: verificationId ?? this.verificationId,
      isLoading: isLoading ?? this.isLoading,
      error: error,
      phoneNumber: phoneNumber ?? this.phoneNumber,
    );
  }
}

class OtpFlowNotifier extends StateNotifier<OtpFlowState> {
  OtpFlowNotifier(this._authService) : super(const OtpFlowState());

  final AuthService _authService;

  Future<void> sendOtp(String e164Phone) async {
    state = state.copyWith(
        isLoading: true, error: null, phoneNumber: e164Phone);
    try {
      await _authService.sendOtp(
        phoneNumber: e164Phone,
        onCodeSent: (verificationId) {
          state = state.copyWith(
              verificationId: verificationId, isLoading: false);
        },
        onAutoVerified: (_) {
          state = state.copyWith(isLoading: false);
        },
        onFailed: (e) {
          state = state.copyWith(
              isLoading: false, error: e.message ?? 'Verification failed');
        },
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  Future<UserCredential?> verifyOtp(String smsCode) async {
    final verificationId = state.verificationId;
    if (verificationId == null) {
      state = state.copyWith(error: 'Please request a new OTP');
      return null;
    }
    state = state.copyWith(isLoading: true, error: null);
    try {
      final result = await _authService.verifyOtp(
        verificationId: verificationId,
        smsCode: smsCode,
      );
      state = state.copyWith(isLoading: false);
      return result;
    } on FirebaseAuthException catch (e) {
      state = state.copyWith(
          isLoading: false, error: e.message ?? 'Invalid OTP');
      return null;
    }
  }
}

final otpFlowProvider =
    StateNotifierProvider<OtpFlowNotifier, OtpFlowState>((ref) {
  return OtpFlowNotifier(ref.watch(authServiceProvider));
});
