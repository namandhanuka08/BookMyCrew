enum SortBy { distance, priceLowToHigh, ratingHighToLow, experience }

/// Immutable snapshot of everything the search screen's filter sheet
/// controls. Kept separate from the provider's async list state so
/// "change a filter" and "the list that resulted" are distinct,
/// independently testable pieces of state.
class SearchFilters {
  const SearchFilters({
    this.category,
    this.city = 'Bengaluru',
    this.minPrice,
    this.maxPrice,
    this.minRating,
    this.availableDate,
    this.maxDistanceKm,
    this.sortBy = SortBy.distance,
  });

  final String? category;
  final String city;
  final double? minPrice;
  final double? maxPrice;
  final double? minRating;
  final DateTime? availableDate;
  final double? maxDistanceKm;
  final SortBy sortBy;

  SearchFilters copyWith({
    String? category,
    bool clearCategory = false,
    String? city,
    double? minPrice,
    double? maxPrice,
    double? minRating,
    DateTime? availableDate,
    double? maxDistanceKm,
    SortBy? sortBy,
  }) {
    return SearchFilters(
      category: clearCategory ? null : (category ?? this.category),
      city: city ?? this.city,
      minPrice: minPrice ?? this.minPrice,
      maxPrice: maxPrice ?? this.maxPrice,
      minRating: minRating ?? this.minRating,
      availableDate: availableDate ?? this.availableDate,
      maxDistanceKm: maxDistanceKm ?? this.maxDistanceKm,
      sortBy: sortBy ?? this.sortBy,
    );
  }

  int get activeFilterCount {
    var count = 0;
    if (category != null) count++;
    if (minPrice != null || maxPrice != null) count++;
    if (minRating != null) count++;
    if (availableDate != null) count++;
    if (maxDistanceKm != null) count++;
    return count;
  }
}
