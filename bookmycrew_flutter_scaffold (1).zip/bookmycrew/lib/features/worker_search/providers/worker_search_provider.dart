import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import '../../../core/models/worker_model.dart';
import '../models/search_filters.dart';
import '../services/worker_search_service.dart';

final workerSearchServiceProvider =
    Provider<WorkerSearchService>((ref) => WorkerSearchService());

class WorkerSearchState {
  const WorkerSearchState({
    this.workers = const [],
    this.filters = const SearchFilters(),
    this.isLoading = false,
    this.isLoadingMore = false,
    this.hasMore = true,
    this.error,
    this.lastDoc,
    this.userLat,
    this.userLng,
  });

  final List<Worker> workers;
  final SearchFilters filters;
  final bool isLoading; // first load / filter change / refresh
  final bool isLoadingMore; // pagination in flight
  final bool hasMore;
  final String? error;
  final DocumentSnapshot<Map<String, dynamic>>? lastDoc;
  final double? userLat;
  final double? userLng;

  WorkerSearchState copyWith({
    List<Worker>? workers,
    SearchFilters? filters,
    bool? isLoading,
    bool? isLoadingMore,
    bool? hasMore,
    String? error,
    bool clearError = false,
    DocumentSnapshot<Map<String, dynamic>>? lastDoc,
    double? userLat,
    double? userLng,
  }) {
    return WorkerSearchState(
      workers: workers ?? this.workers,
      filters: filters ?? this.filters,
      isLoading: isLoading ?? this.isLoading,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
      hasMore: hasMore ?? this.hasMore,
      error: clearError ? null : (error ?? this.error),
      lastDoc: lastDoc ?? this.lastDoc,
      userLat: userLat ?? this.userLat,
      userLng: userLng ?? this.userLng,
    );
  }
}

class WorkerSearchNotifier extends StateNotifier<WorkerSearchState> {
  WorkerSearchNotifier(this._service) : super(const WorkerSearchState()) {
    _init();
  }

  final WorkerSearchService _service;

  Future<void> _init() async {
    await _resolveLocation();
    await refresh();
  }

  Future<void> _resolveLocation() async {
    try {
      final permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        final requested = await Geolocator.requestPermission();
        if (requested == LocationPermission.denied ||
            requested == LocationPermission.deniedForever) {
          return; // Distance sort/filter silently unavailable; UI
          // degrades to crewScore ordering, which is fine.
        }
      }
      final position = await Geolocator.getCurrentPosition();
      state = state.copyWith(userLat: position.latitude, userLng: position.longitude);
    } catch (_) {
      // Best-effort only — search still works without location.
    }
  }

  Future<void> refresh() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final page = await _service.fetchPage(
        filters: state.filters,
        userLat: state.userLat,
        userLng: state.userLng,
      );
      state = state.copyWith(
        workers: page.workers,
        lastDoc: page.lastDoc,
        hasMore: page.hasMore,
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  Future<void> loadMore() async {
    if (state.isLoadingMore || !state.hasMore || state.lastDoc == null) return;
    state = state.copyWith(isLoadingMore: true);
    try {
      final page = await _service.fetchPage(
        filters: state.filters,
        startAfter: state.lastDoc,
        userLat: state.userLat,
        userLng: state.userLng,
      );
      state = state.copyWith(
        workers: [...state.workers, ...page.workers],
        lastDoc: page.lastDoc,
        hasMore: page.hasMore,
        isLoadingMore: false,
      );
    } catch (e) {
      state = state.copyWith(isLoadingMore: false, error: e.toString());
    }
  }

  Future<void> applyFilters(SearchFilters filters) async {
    state = state.copyWith(filters: filters, lastDoc: null);
    await refresh();
  }

  Future<void> setCategory(String? category) async {
    await applyFilters(state.filters.copyWith(
      category: category,
      clearCategory: category == null,
    ));
  }
}

final workerSearchProvider =
    StateNotifierProvider<WorkerSearchNotifier, WorkerSearchState>((ref) {
  return WorkerSearchNotifier(ref.watch(workerSearchServiceProvider));
});
