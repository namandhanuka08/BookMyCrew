import 'dart:math' as math;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import '../../../core/models/worker_model.dart';
import '../models/search_filters.dart';

/// Builds and paginates the `workers` collection query.
///
/// Firestore can only apply range/orderBy across one field per query
/// without a matching composite index, so the query itself only does
/// what's cheap and always-indexed-friendly: equality on
/// `verificationStatus` + `city` (+ optional `categories`
/// array-contains), and a single `orderBy` matching the chosen sort.
/// Price range, minimum rating, and availability-date are applied
/// client-side on the fetched page. Distance is always computed and
/// sorted client-side since Firestore has no native geo query.
///
/// This is the right tradeoff for MVP city-scale volumes (hundreds to
/// low thousands of workers per city). If a city's worker count grows
/// past what comfortably fits in a few paginated reads, swap this for
/// a dedicated search index (Algolia/Typesense) fed by a Cloud
/// Function on worker-doc writes — the provider layer above this
/// service wouldn't need to change, only this file.
class WorkerSearchService {
  WorkerSearchService({FirebaseFirestore? firestore})
      : _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;
  static const int pageSize = 12;

  Query<Map<String, dynamic>> _baseQuery(SearchFilters filters) {
    Query<Map<String, dynamic>> query = _db
        .collection('workers')
        .where('verificationStatus', isEqualTo: 'verified')
        .where('city', isEqualTo: filters.city);

    if (filters.category != null) {
      query = query.where('categories', arrayContains: filters.category);
    }

    switch (filters.sortBy) {
      case SortBy.priceLowToHigh:
        query = query.orderBy('hourRate');
        break;
      case SortBy.ratingHighToLow:
        query = query.orderBy('ratingAvg', descending: true);
        break;
      case SortBy.experience:
        query = query.orderBy('experienceYears', descending: true);
        break;
      case SortBy.distance:
        // No server-side geo ordering available; fall back to
        // ordering by crewScore so the first page is still
        // meaningfully ranked before client-side distance sort runs.
        query = query.orderBy('crewScore', descending: true);
        break;
    }

    return query;
  }

  Future<WorkerSearchPage> fetchPage({
    required SearchFilters filters,
    DocumentSnapshot<Map<String, dynamic>>? startAfter,
    double? userLat,
    double? userLng,
  }) async {
    var query = _baseQuery(filters).limit(pageSize);
    if (startAfter != null) {
      query = query.startAfterDocument(startAfter);
    }

    final snapshot = await query.get();
    var workers = snapshot.docs.map(Worker.fromFirestore).toList();

    // Client-side refinement for fields that can't share a composite
    // index with the equality/orderBy above.
    if (filters.minPrice != null) {
      workers = workers.where((w) => w.hourRate >= filters.minPrice!).toList();
    }
    if (filters.maxPrice != null) {
      workers = workers.where((w) => w.hourRate <= filters.maxPrice!).toList();
    }
    if (filters.minRating != null) {
      workers =
          workers.where((w) => w.ratingAvg >= filters.minRating!).toList();
    }
    if (filters.availableDate != null) {
      final dateStr = DateFormat('yyyy-MM-dd').format(filters.availableDate!);
      workers =
          workers.where((w) => w.availableDates.contains(dateStr)).toList();
    }

    if (userLat != null && userLng != null) {
      workers = workers.map((w) {
        if (w.lat == null || w.lng == null) return w;
        final km = _haversineKm(userLat, userLng, w.lat!, w.lng!);
        return w.copyWith(distanceKm: km);
      }).toList();

      if (filters.maxDistanceKm != null) {
        workers = workers
            .where((w) =>
                w.distanceKm == null || w.distanceKm! <= filters.maxDistanceKm!)
            .toList();
      }

      if (filters.sortBy == SortBy.distance) {
        workers.sort((a, b) {
          final da = a.distanceKm ?? double.maxFinite;
          final db = b.distanceKm ?? double.maxFinite;
          return da.compareTo(db);
        });
      }
    }

    return WorkerSearchPage(
      workers: workers,
      lastDoc: snapshot.docs.isEmpty ? null : snapshot.docs.last,
      hasMore: snapshot.docs.length == pageSize,
    );
  }

  double _haversineKm(double lat1, double lng1, double lat2, double lng2) {
    const earthRadiusKm = 6371.0;
    final dLat = _deg2rad(lat2 - lat1);
    final dLng = _deg2rad(lng2 - lng1);
    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(_deg2rad(lat1)) *
            math.cos(_deg2rad(lat2)) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    final c = 2 * math.asin(math.sqrt(a));
    return earthRadiusKm * c;
  }

  double _deg2rad(double deg) => deg * (math.pi / 180.0);
}

class WorkerSearchPage {
  const WorkerSearchPage({
    required this.workers,
    required this.lastDoc,
    required this.hasMore,
  });

  final List<Worker> workers;
  final DocumentSnapshot<Map<String, dynamic>>? lastDoc;
  final bool hasMore;
}
