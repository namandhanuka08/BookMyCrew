import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/models/worker_categories.dart';
import '../../../core/theme/app_colors.dart';
import '../../worker_profile/screens/worker_profile_screen.dart';
import '../models/search_filters.dart';
import '../providers/worker_search_provider.dart';
import '../widgets/filter_bottom_sheet.dart';
import '../widgets/worker_card.dart';
import '../widgets/worker_card_skeleton.dart';

class WorkerSearchScreen extends ConsumerStatefulWidget {
  const WorkerSearchScreen({super.key});

  @override
  ConsumerState<WorkerSearchScreen> createState() =>
      _WorkerSearchScreenState();
}

class _WorkerSearchScreenState extends ConsumerState<WorkerSearchScreen> {
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 400) {
      ref.read(workerSearchProvider.notifier).loadMore();
    }
  }

  void _openFilters(SearchFilters current) {
    FilterBottomSheet.show(
      context,
      initialFilters: current,
      onApply: (filters) =>
          ref.read(workerSearchProvider.notifier).applyFilters(filters),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(workerSearchProvider);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(state.filters.city),
        actions: [
          IconButton(
            icon: Badge(
              isLabelVisible: state.filters.activeFilterCount > 0,
              label: Text('${state.filters.activeFilterCount}'),
              backgroundColor: AppColors.gold,
              textColor: AppColors.background,
              child: const Icon(Icons.tune),
            ),
            onPressed: () => _openFilters(state.filters),
          ),
        ],
      ),
      body: Column(
        children: [
          _CategoryChipRow(
            selected: state.filters.category,
            onSelected: (c) =>
                ref.read(workerSearchProvider.notifier).setCategory(c),
          ),
          const Divider(height: 1),
          Expanded(
            child: RefreshIndicator(
              color: AppColors.gold,
              backgroundColor: AppColors.surface,
              onRefresh: () => ref.read(workerSearchProvider.notifier).refresh(),
              child: _buildBody(state, theme),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody(WorkerSearchState state, ThemeData theme) {
    if (state.isLoading && state.workers.isEmpty) {
      return ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: 5,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (_, __) => const WorkerCardSkeleton(),
      );
    }

    if (state.error != null && state.workers.isEmpty) {
      return ListView(
        children: [
          const SizedBox(height: 80),
          Icon(Icons.wifi_off, size: 40, color: theme.colorScheme.error),
          const SizedBox(height: 12),
          Center(
            child: Text("Couldn't load workers", style: theme.textTheme.titleMedium),
          ),
          const SizedBox(height: 4),
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Text(
                state.error!,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyMedium,
              ),
            ),
          ),
        ],
      );
    }

    if (state.workers.isEmpty) {
      return ListView(
        children: [
          const SizedBox(height: 100),
          Icon(Icons.search_off, size: 40, color: theme.colorScheme.onSurface.withOpacity(0.4)),
          const SizedBox(height: 12),
          Center(
            child: Text('No workers match these filters',
                style: theme.textTheme.titleMedium),
          ),
          const SizedBox(height: 4),
          Center(
            child: Text('Try widening your price range or distance',
                style: theme.textTheme.bodyMedium),
          ),
        ],
      );
    }

    return ListView.separated(
      controller: _scrollController,
      padding: const EdgeInsets.all(16),
      itemCount: state.workers.length + (state.hasMore ? 1 : 0),
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        if (index >= state.workers.length) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 20),
            child: Center(
              child: SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: AppColors.gold),
              ),
            ),
          );
        }
        final worker = state.workers[index];
        return WorkerCard(
          worker: worker,
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => WorkerProfileScreen(workerId: worker.uid),
              ),
            );
          },
        );
      },
    );
  }
}

class _CategoryChipRow extends StatelessWidget {
  const _CategoryChipRow({required this.selected, required this.onSelected});

  final String? selected;
  final ValueChanged<String?> onSelected;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 56,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        itemCount: WorkerCategories.mvpEnabled.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final category = WorkerCategories.mvpEnabled[index];
          final isSelected = selected == category;
          return ChoiceChip(
            label: Text(category),
            selected: isSelected,
            onSelected: (_) => onSelected(isSelected ? null : category),
          );
        },
      ),
    );
  }
}
