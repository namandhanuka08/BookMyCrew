import 'package:flutter/material.dart';
import '../../../core/models/worker_categories.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/gold_thread_indicator.dart';
import '../models/search_filters.dart';

/// Bottom sheet holds a *draft* copy of filters and only reports it
/// back via [onApply] — nothing is pushed to Firestore until the user
/// taps Apply, so opening the sheet and backing out costs nothing.
class FilterBottomSheet extends StatefulWidget {
  const FilterBottomSheet({
    super.key,
    required this.initialFilters,
    required this.onApply,
  });

  final SearchFilters initialFilters;
  final ValueChanged<SearchFilters> onApply;

  static Future<void> show(
    BuildContext context, {
    required SearchFilters initialFilters,
    required ValueChanged<SearchFilters> onApply,
  }) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.background,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => FilterBottomSheet(
        initialFilters: initialFilters,
        onApply: onApply,
      ),
    );
  }

  @override
  State<FilterBottomSheet> createState() => _FilterBottomSheetState();
}

class _FilterBottomSheetState extends State<FilterBottomSheet> {
  late SearchFilters _draft;
  late RangeValues _priceRange;

  static const double _priceFloor = 100;
  static const double _priceCeiling = 3000;

  @override
  void initState() {
    super.initState();
    _draft = widget.initialFilters;
    _priceRange = RangeValues(
      _draft.minPrice ?? _priceFloor,
      _draft.maxPrice ?? _priceCeiling,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        return Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 16,
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          child: ListView(
            controller: scrollController,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.divider,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text('Filters', style: theme.textTheme.headlineLarge),
              const SizedBox(height: 24),

              Text('Category', style: theme.textTheme.titleMedium),
              const SizedBox(height: 12),
              _CategoryChips(
                selected: _draft.category,
                onSelected: (c) => setState(() =>
                    _draft = _draft.copyWith(category: c, clearCategory: c == null)),
              ),
              const SizedBox(height: 24),

              Text('Hourly rate', style: theme.textTheme.titleMedium),
              const SizedBox(height: 4),
              Text(
                '₹${_priceRange.start.round()} – ₹${_priceRange.end.round()}',
                style: theme.textTheme.bodyMedium,
              ),
              RangeSlider(
                values: _priceRange,
                min: _priceFloor,
                max: _priceCeiling,
                divisions: 29,
                activeColor: AppColors.gold,
                inactiveColor: AppColors.divider,
                onChanged: (v) => setState(() => _priceRange = v),
              ),
              const SizedBox(height: 12),

              Text('Minimum rating', style: theme.textTheme.titleMedium),
              const SizedBox(height: 12),
              _RatingSelector(
                selected: _draft.minRating,
                onSelected: (r) => setState(
                    () => _draft = _draft.copyWith(minRating: r)),
              ),
              const SizedBox(height: 24),

              Text('Max distance', style: theme.textTheme.titleMedium),
              const SizedBox(height: 4),
              Text(
                _draft.maxDistanceKm == null
                    ? 'Any distance'
                    : '${_draft.maxDistanceKm!.round()} km',
                style: theme.textTheme.bodyMedium,
              ),
              Slider(
                value: _draft.maxDistanceKm ?? 25,
                min: 1,
                max: 25,
                divisions: 24,
                activeColor: AppColors.gold,
                inactiveColor: AppColors.divider,
                onChanged: (v) =>
                    setState(() => _draft = _draft.copyWith(maxDistanceKm: v)),
              ),
              const SizedBox(height: 24),

              Text('Sort by', style: theme.textTheme.titleMedium),
              const SizedBox(height: 12),
              _SortChips(
                selected: _draft.sortBy,
                onSelected: (s) =>
                    setState(() => _draft = _draft.copyWith(sortBy: s)),
              ),
              const SizedBox(height: 32),

              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () {
                        setState(() {
                          _draft = SearchFilters(city: _draft.city);
                          _priceRange =
                              const RangeValues(_priceFloor, _priceCeiling);
                        });
                      },
                      child: const Text('Reset'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: ElevatedButton(
                      onPressed: () {
                        widget.onApply(_draft.copyWith(
                          minPrice: _priceRange.start,
                          maxPrice: _priceRange.end,
                        ));
                        Navigator.of(context).pop();
                      },
                      child: const Text('Apply filters'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _CategoryChips extends StatelessWidget {
  const _CategoryChips({required this.selected, required this.onSelected});

  final String? selected;
  final ValueChanged<String?> onSelected;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: WorkerCategories.mvpEnabled.map((category) {
        final isSelected = selected == category;
        return ChoiceChip(
          label: Text(category),
          selected: isSelected,
          onSelected: (_) => onSelected(isSelected ? null : category),
        );
      }).toList(),
    );
  }
}

class _RatingSelector extends StatelessWidget {
  const _RatingSelector({required this.selected, required this.onSelected});

  final double? selected;
  final ValueChanged<double?> onSelected;

  @override
  Widget build(BuildContext context) {
    const options = [3.0, 3.5, 4.0, 4.5];
    return Wrap(
      spacing: 8,
      children: options.map((rating) {
        final isSelected = selected == rating;
        return ChoiceChip(
          label: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.star_rounded, size: 14, color: AppColors.gold),
              const SizedBox(width: 2),
              Text('$rating+'),
            ],
          ),
          selected: isSelected,
          onSelected: (_) => onSelected(isSelected ? null : rating),
        );
      }).toList(),
    );
  }
}

class _SortChips extends StatelessWidget {
  const _SortChips({required this.selected, required this.onSelected});

  final SortBy selected;
  final ValueChanged<SortBy> onSelected;

  static const _labels = {
    SortBy.distance: 'Nearest',
    SortBy.priceLowToHigh: 'Price: low to high',
    SortBy.ratingHighToLow: 'Top rated',
    SortBy.experience: 'Most experienced',
  };

  @override
  Widget build(BuildContext context) {
    return Column(
      children: _labels.entries.map((entry) {
        final isSelected = selected == entry.key;
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: InkWell(
            onTap: () => onSelected(entry.key),
            borderRadius: BorderRadius.circular(12),
            child: Row(
              children: [
                Icon(
                  isSelected
                      ? Icons.radio_button_checked
                      : Icons.radio_button_off,
                  color: isSelected ? AppColors.gold : AppColors.textSecondary,
                  size: 20,
                ),
                const SizedBox(width: 10),
                Text(entry.value,
                    style: Theme.of(context).textTheme.bodyLarge),
                if (isSelected) ...[
                  const SizedBox(width: 8),
                  const GoldThreadIndicator(width: 20, active: true),
                ],
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}
