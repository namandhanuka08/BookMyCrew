import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';

/// CrewScore is the composite 0–100 trust score. Shown as a small
/// pill so it reads at a glance next to the star rating without
/// competing with it — rating is "how did past customers feel",
/// CrewScore is "how reliable is this worker overall" (acceptance
/// rate, punctuality history, consistency). Color shifts subtly by
/// tier so a 95 visually outranks a 60 even before reading the number.
class CrewScorePill extends StatelessWidget {
  const CrewScorePill({super.key, required this.score});

  final int score;

  Color get _tint {
    if (score >= 90) return AppColors.goldBright;
    if (score >= 75) return AppColors.gold;
    if (score >= 50) return AppColors.textSecondary;
    return AppColors.textDisabled;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        border: Border.all(color: _tint.withOpacity(0.5)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.bolt, size: 12, color: _tint),
          const SizedBox(width: 2),
          Text(
            'CrewScore $score',
            style: TextStyle(
              color: _tint,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
