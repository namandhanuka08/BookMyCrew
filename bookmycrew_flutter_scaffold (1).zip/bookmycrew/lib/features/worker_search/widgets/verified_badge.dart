import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';

/// Small gold check badge — the one place gold is used as a literal
/// icon rather than a line/accent, because "verified" is exactly the
/// kind of trust signal worth spending the accent color on.
class VerifiedBadge extends StatelessWidget {
  const VerifiedBadge({super.key, this.size = 18});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        color: AppColors.gold,
        shape: BoxShape.circle,
      ),
      child: Icon(Icons.check, size: size * 0.7, color: AppColors.background),
    );
  }
}
