import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import '../../../core/theme/app_colors.dart';

/// Mirrors WorkerCard's exact layout (avatar + 3 text lines + tag row
/// + price row) so the shimmer-to-content swap doesn't cause a layout
/// jump — the skeleton IS the card's skeleton, not a generic block.
class WorkerCardSkeleton extends StatelessWidget {
  const WorkerCardSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: AppColors.surface,
      highlightColor: AppColors.surfaceElevated,
      period: const Duration(milliseconds: 1400),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.divider),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _block(width: 72, height: 72, radius: 14),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _block(width: 140, height: 16),
                  const SizedBox(height: 8),
                  _block(width: 100, height: 12),
                  const SizedBox(height: 10),
                  _block(width: 160, height: 12),
                  const SizedBox(height: 10),
                  _block(width: double.infinity, height: 22),
                  const SizedBox(height: 12),
                  _block(width: double.infinity, height: 36),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _block({required double width, required double height, double radius = 6}) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(radius),
      ),
    );
  }
}
