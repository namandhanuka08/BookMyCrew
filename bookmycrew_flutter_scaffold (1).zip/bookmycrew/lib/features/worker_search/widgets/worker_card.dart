import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../../../core/models/worker_model.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/app_card.dart';
import 'crew_score_pill.dart';
import 'verified_badge.dart';

class WorkerCard extends StatelessWidget {
  const WorkerCard({super.key, required this.worker, required this.onTap});

  final Worker worker;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return AppCard(
      onTap: onTap,
      padding: const EdgeInsets.all(14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _Avatar(worker: worker),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        worker.name,
                        style: theme.textTheme.titleMedium,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (worker.isVerified) ...[
                      const SizedBox(width: 6),
                      const VerifiedBadge(),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  worker.categories.join(' · '),
                  style: theme.textTheme.bodyMedium,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.star_rounded,
                        size: 15, color: AppColors.gold),
                    const SizedBox(width: 2),
                    Text(
                      worker.ratingAvg.toStringAsFixed(1),
                      style: theme.textTheme.labelLarge,
                    ),
                    Text(
                      ' (${worker.ratingCount})',
                      style: theme.textTheme.bodyMedium,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      '${worker.completedJobs} jobs',
                      style: theme.textTheme.bodyMedium,
                    ),
                    if (worker.distanceKm != null) ...[
                      const SizedBox(width: 10),
                      Icon(Icons.place_outlined,
                          size: 13, color: AppColors.textSecondary),
                      Text(
                        ' ${worker.distanceKm!.toStringAsFixed(1)} km',
                        style: theme.textTheme.bodyMedium,
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    CrewScorePill(score: worker.crewScore),
                    _MiniTag(text: '${worker.experienceYears}+ yrs exp'),
                    if (worker.languages.isNotEmpty)
                      _MiniTag(text: worker.languages.take(2).join(', ')),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '₹${worker.hourRate.toStringAsFixed(0)}/hr',
                      style: AppTypography.priceText,
                    ),
                    OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size(0, 36),
                        padding:
                            const EdgeInsets.symmetric(horizontal: 16),
                      ),
                      onPressed: onTap,
                      child: const Text('View profile'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({required this.worker});

  final Worker worker;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: SizedBox(
        width: 72,
        height: 72,
        child: worker.profilePhotoUrl == null
            ? Container(
                color: AppColors.surfaceElevated,
                child: const Icon(Icons.person,
                    color: AppColors.textSecondary, size: 32),
              )
            : CachedNetworkImage(
                imageUrl: worker.profilePhotoUrl!,
                fit: BoxFit.cover,
                placeholder: (_, __) =>
                    Container(color: AppColors.surfaceElevated),
                errorWidget: (_, __, ___) => Container(
                  color: AppColors.surfaceElevated,
                  child: const Icon(Icons.person,
                      color: AppColors.textSecondary, size: 32),
                ),
              ),
      ),
    );
  }
}

class _MiniTag extends StatelessWidget {
  const _MiniTag({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: AppColors.surfaceElevated,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: AppColors.textSecondary,
          fontSize: 11,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
