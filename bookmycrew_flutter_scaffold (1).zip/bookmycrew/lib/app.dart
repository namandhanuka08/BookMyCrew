import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/theme/app_theme.dart';
import 'features/auth/providers/auth_provider.dart';
import 'features/auth/screens/phone_input_screen.dart';
import 'features/worker_search/screens/worker_search_screen.dart';

class BookMyCrewApp extends ConsumerWidget {
  const BookMyCrewApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);

    return MaterialApp(
      title: 'BookMyCrew',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      themeMode: ThemeMode.dark,
      home: authState.when(
        data: (user) => user == null
            ? const PhoneInputScreen()
            : const WorkerSearchScreen(),
        loading: () => const _SplashScreen(),
        error: (_, __) => const PhoneInputScreen(),
      ),
    );
  }
}

class _SplashScreen extends StatelessWidget {
  const _SplashScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}
