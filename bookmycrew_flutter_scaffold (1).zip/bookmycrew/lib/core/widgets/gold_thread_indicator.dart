import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// The app's one signature motion element.
///
/// A thin gold line that *draws itself* left-to-right when something
/// becomes active — a selected category chip, the focused OTP box, an
/// active bottom-nav tab. Everywhere else in the app stays still. Using
/// this in exactly those three places (never as generic decoration)
/// means the one bit of "premium" motion in the whole app always means
/// the same thing: "this is the active one."
class GoldThreadIndicator extends StatefulWidget {
  const GoldThreadIndicator({
    super.key,
    this.width = 32,
    this.height = 2.5,
    this.active = true,
    this.duration = const Duration(milliseconds: 260),
  });

  final double width;
  final double height;
  final bool active;
  final Duration duration;

  @override
  State<GoldThreadIndicator> createState() => _GoldThreadIndicatorState();
}

class _GoldThreadIndicatorState extends State<GoldThreadIndicator>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: widget.duration);
    _scale = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    if (widget.active) _controller.forward();
  }

  @override
  void didUpdateWidget(covariant GoldThreadIndicator oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.active && !oldWidget.active) {
      _controller.forward(from: 0);
    } else if (!widget.active && oldWidget.active) {
      _controller.reverse();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: ScaleTransition(
        scale: _scale,
        alignment: Alignment.centerLeft,
        child: Container(
          width: widget.width,
          height: widget.height,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppColors.gold, AppColors.goldBright],
            ),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ),
    );
  }
}
