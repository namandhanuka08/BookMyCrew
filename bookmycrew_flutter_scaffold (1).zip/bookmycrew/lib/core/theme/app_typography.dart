import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

/// Type system: Fraunces (a warm, slightly editorial serif with real
/// character in its italics) for display moments — the app name,
/// booking confirmations, empty states — paired with Inter for every
/// UI surface where legibility at small sizes matters (lists, forms,
/// prices). This avoids the generic "geometric sans everywhere" look
/// while keeping dense screens (worker lists, booking cards) fast to
/// scan.
class AppTypography {
  AppTypography._();

  static TextTheme get textTheme => TextTheme(
        // Display — Fraunces, used only for hero/confirmation moments
        displayLarge: GoogleFonts.fraunces(
          fontSize: 34,
          fontWeight: FontWeight.w600,
          fontStyle: FontStyle.italic,
          color: AppColors.textPrimary,
          height: 1.15,
        ),
        displayMedium: GoogleFonts.fraunces(
          fontSize: 26,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
          height: 1.2,
        ),

        // Headlines — Fraunces, upright, screen titles
        headlineLarge: GoogleFonts.fraunces(
          fontSize: 22,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
        ),
        headlineMedium: GoogleFonts.fraunces(
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
        ),

        // Body / UI — Inter, everything functional
        titleMedium: GoogleFonts.inter(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
        ),
        bodyLarge: GoogleFonts.inter(
          fontSize: 15,
          fontWeight: FontWeight.w400,
          color: AppColors.textPrimary,
          height: 1.4,
        ),
        bodyMedium: GoogleFonts.inter(
          fontSize: 13,
          fontWeight: FontWeight.w400,
          color: AppColors.textSecondary,
          height: 1.4,
        ),
        labelLarge: GoogleFonts.inter(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
          letterSpacing: 0.2,
        ),
        labelSmall: GoogleFonts.inter(
          fontSize: 11,
          fontWeight: FontWeight.w500,
          color: AppColors.textSecondary,
          letterSpacing: 0.4,
        ),
      );

  /// Tabular-figure style for prices/rates so amounts align in lists
  /// (worker day-rate cards, invoices).
  static TextStyle get priceText => GoogleFonts.inter(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: AppColors.gold,
        fontFeatures: const [FontFeature.tabularFigures()],
      );
}
