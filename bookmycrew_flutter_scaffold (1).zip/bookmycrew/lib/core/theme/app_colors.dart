import 'package:flutter/material.dart';

/// BookMyCrew design tokens — palette.
///
/// Direction: "backstage gold" — a near-black stage with a single warm
/// gold thread running through it, rather than gold-as-decoration
/// everywhere. Gold is reserved for the signature element (see
/// AppTheme doc comment) and for primary actions/status — not for
/// borders, icons, or text by default. This keeps it premium instead
/// of loud.
class AppColors {
  AppColors._();

  // Base surfaces — never pure black/white, both carry a warm undertone
  // so gold sits naturally against them instead of looking bolted on.
  static const Color background = Color(0xFF0B0B0D);
  static const Color surface = Color(0xFF17171B);
  static const Color surfaceElevated = Color(0xFF1F1F24);
  static const Color divider = Color(0xFF2A2A2F);

  // Gold — the signature. Two weights only: a muted base for resting
  // states, a brighter one reserved for the active "thread" (see
  // GoldThreadIndicator) and primary CTAs.
  static const Color gold = Color(0xFFCBA135);
  static const Color goldBright = Color(0xFFE3C567);

  // Text — warm off-white / muted, never pure #FFFFFF.
  static const Color textPrimary = Color(0xFFF5F4EF);
  static const Color textSecondary = Color(0xFF9C9CA3);
  static const Color textDisabled = Color(0xFF5C5C63);

  // Status
  static const Color success = Color(0xFF3FCF8E);
  static const Color error = Color(0xFFE5484D);
  static const Color warning = Color(0xFFE3A73D);

  // Role accents (used sparingly — e.g. small badges to distinguish
  // roles in the admin panel; never as primary buttons)
  static const Color customerAccent = Color(0xFF6FA8DC);
  static const Color workerAccent = Color(0xFFCBA135);
  static const Color eventManagerAccent = Color(0xFF9C89B8);
}
