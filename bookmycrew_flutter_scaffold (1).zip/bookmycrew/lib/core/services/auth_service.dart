import 'package:firebase_auth/firebase_auth.dart';

/// Wraps Firebase Phone Auth. Kept framework-agnostic (no Riverpod
/// imports here) so it can be unit-tested or swapped without touching
/// the provider layer.
class AuthService {
  AuthService({FirebaseAuth? firebaseAuth})
      : _auth = firebaseAuth ?? FirebaseAuth.instance;

  final FirebaseAuth _auth;

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  /// Starts phone verification. [onCodeSent] fires once Firebase has
  /// dispatched the OTP; the returned verificationId is what
  /// [verifyOtp] needs. [onAutoVerified] fires on Android instant
  /// SMS-retrieval — handle it by signing the user straight in.
  Future<void> sendOtp({
    required String phoneNumber, // E.164 format, e.g. +919876543210
    required void Function(String verificationId) onCodeSent,
    required void Function(UserCredential credential) onAutoVerified,
    required void Function(FirebaseAuthException error) onFailed,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (PhoneAuthCredential credential) async {
        final result = await _auth.signInWithCredential(credential);
        onAutoVerified(result);
      },
      verificationFailed: onFailed,
      codeSent: (String verificationId, int? resendToken) {
        onCodeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  Future<UserCredential> verifyOtp({
    required String verificationId,
    required String smsCode,
  }) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    return _auth.signInWithCredential(credential);
  }

  Future<void> signOut() => _auth.signOut();
}
