/// Central list of worker categories. MVP launches with a subset (see
/// architecture doc — Waiter/Bartender/Chef/Decorator); the rest are
/// kept here so search/filter UI doesn't need code changes as
/// categories are enabled — just extend this list.
class WorkerCategories {
  WorkerCategories._();

  static const List<String> all = [
    'Waiter',
    'Steward',
    'Bartender',
    'Chef',
    'Cleaner',
    'Decorator',
    'Security Guard',
    'Helper',
    'Photographer',
    'Videographer',
    'DJ',
    'Host/Hostess',
    'Makeup Artist',
  ];

  /// Categories live in the MVP (see architecture doc Phase 1 scope).
  static const List<String> mvpEnabled = [
    'Waiter',
    'Bartender',
    'Chef',
    'Decorator',
  ];
}
