import 'package:cloud_firestore/cloud_firestore.dart';

/// Matches `workers/{uid}` in Firestore. `distanceKm` is never stored —
/// it's computed client-side against the searching customer's current
/// location and attached after the fact (see WorkerSearchService).
class Worker {
  const Worker({
    required this.uid,
    required this.name,
    required this.categories,
    required this.city,
    required this.languages,
    required this.experienceYears,
    required this.hourRate,
    required this.dayRate,
    required this.verificationStatus,
    required this.ratingAvg,
    required this.ratingCount,
    required this.completedJobs,
    required this.crewScore,
    this.profilePhotoUrl,
    this.portfolioUrls = const [],
    this.lat,
    this.lng,
    this.availableDates = const [],
    this.distanceKm,
  });

  final String uid;
  final String name;
  final List<String> categories;
  final String city;
  final List<String> languages;
  final int experienceYears;
  final double hourRate;
  final double dayRate;
  final String verificationStatus; // "pending" | "verified" | "rejected"
  final double ratingAvg;
  final int ratingCount;
  final int completedJobs;

  /// 0–100 composite score (rating consistency, acceptance rate,
  /// punctuality history). Computed server-side by a Cloud Function;
  /// this module only displays it.
  final int crewScore;

  final String? profilePhotoUrl;
  final List<String> portfolioUrls;
  final double? lat;
  final double? lng;

  /// Dates (yyyy-MM-dd) this worker has marked themselves available.
  final List<String> availableDates;

  final double? distanceKm;

  bool get isVerified => verificationStatus == 'verified';

  Worker copyWith({double? distanceKm}) {
    return Worker(
      uid: uid,
      name: name,
      categories: categories,
      city: city,
      languages: languages,
      experienceYears: experienceYears,
      hourRate: hourRate,
      dayRate: dayRate,
      verificationStatus: verificationStatus,
      ratingAvg: ratingAvg,
      ratingCount: ratingCount,
      completedJobs: completedJobs,
      crewScore: crewScore,
      profilePhotoUrl: profilePhotoUrl,
      portfolioUrls: portfolioUrls,
      lat: lat,
      lng: lng,
      availableDates: availableDates,
      distanceKm: distanceKm ?? this.distanceKm,
    );
  }

  factory Worker.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};
    return Worker(
      uid: doc.id,
      name: data['name'] as String? ?? 'Unnamed',
      categories: List<String>.from(data['categories'] as List? ?? const []),
      city: data['city'] as String? ?? '',
      languages: List<String>.from(data['languages'] as List? ?? const []),
      experienceYears: (data['experienceYears'] as num?)?.toInt() ?? 0,
      hourRate: (data['hourRate'] as num?)?.toDouble() ?? 0,
      dayRate: (data['dayRate'] as num?)?.toDouble() ?? 0,
      verificationStatus: data['verificationStatus'] as String? ?? 'pending',
      ratingAvg: (data['ratingAvg'] as num?)?.toDouble() ?? 0,
      ratingCount: (data['ratingCount'] as num?)?.toInt() ?? 0,
      completedJobs: (data['completedJobs'] as num?)?.toInt() ?? 0,
      crewScore: (data['crewScore'] as num?)?.toInt() ?? 0,
      profilePhotoUrl: data['profilePhotoUrl'] as String?,
      portfolioUrls: List<String>.from(data['portfolioUrls'] as List? ?? const []),
      lat: (data['lat'] as num?)?.toDouble(),
      lng: (data['lng'] as num?)?.toDouble(),
      availableDates:
          List<String>.from(data['availableDates'] as List? ?? const []),
    );
  }
}
