import 'package:cloud_firestore/cloud_firestore.dart';

/// Matches `ratings/{ratingId}`. Each of the six sub-scores is 1–5;
/// `overall` is their average, kept precomputed so review lists don't
/// need to recompute it per card.
class Review {
  const Review({
    required this.id,
    required this.customerName,
    required this.punctuality,
    required this.professionalism,
    required this.behaviour,
    required this.grooming,
    required this.communication,
    required this.teamwork,
    required this.createdAt,
    this.comment,
  });

  final String id;
  final String customerName;
  final int punctuality;
  final int professionalism;
  final int behaviour;
  final int grooming;
  final int communication;
  final int teamwork;
  final String? comment;
  final DateTime createdAt;

  double get overall =>
      (punctuality +
          professionalism +
          behaviour +
          grooming +
          communication +
          teamwork) /
      6.0;

  factory Review.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};
    return Review(
      id: doc.id,
      customerName: data['customerName'] as String? ?? 'Customer',
      punctuality: (data['punctuality'] as num?)?.toInt() ?? 0,
      professionalism: (data['professionalism'] as num?)?.toInt() ?? 0,
      behaviour: (data['behaviour'] as num?)?.toInt() ?? 0,
      grooming: (data['grooming'] as num?)?.toInt() ?? 0,
      communication: (data['communication'] as num?)?.toInt() ?? 0,
      teamwork: (data['teamwork'] as num?)?.toInt() ?? 0,
      comment: data['comment'] as String?,
      createdAt:
          (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }
}
