/// Matches the `users/{uid}` Firestore document described in the
/// architecture doc. Role-specific detail (worker categories, rates,
/// etc.) lives in `workers/{uid}` / `customers/{uid}` — this model is
/// just the identity + role record every signed-in person has.
class AppUser {
  const AppUser({
    required this.uid,
    required this.phone,
    required this.role,
    this.name,
    this.fcmToken,
  });

  final String uid;
  final String phone;
  final UserRole role;
  final String? name;
  final String? fcmToken;

  factory AppUser.fromMap(String uid, Map<String, dynamic> map) {
    return AppUser(
      uid: uid,
      phone: map['phone'] as String? ?? '',
      role: UserRole.values.firstWhere(
        (r) => r.name == map['role'],
        orElse: () => UserRole.customer,
      ),
      name: map['name'] as String?,
      fcmToken: map['fcmToken'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
        'phone': phone,
        'role': role.name,
        if (name != null) 'name': name,
        if (fcmToken != null) 'fcmToken': fcmToken,
      };
}

enum UserRole { customer, worker, eventManager, admin }
